// Popup logic placeholder
document.getElementById('batch-mode-btn').addEventListener('click', () => {
    alert('批量模式功能正在开发中：开启后，侧边栏将出现勾选框。');
});

document.getElementById('md-copy-btn').addEventListener('click', () => {
    alert('Markdown 导出功能正在对接中。');
});
